from django.shortcuts import render
from .models import Material

def home(request):
    context = {
            'materials': Material.objects.all()
    }
    return render(request, 'HTML/home.html', context)    

