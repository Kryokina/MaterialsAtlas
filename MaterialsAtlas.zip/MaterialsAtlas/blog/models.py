from django.db import models

# Create your models here.
class Material(models.Model):
    mat_id = models.CharField(max_length=100)
    formula = models.CharField(max_length=100)
    spacegroup = models.CharField(max_length=100)
    formation_energy = models.CharField(max_length=100)
    e_above_hull = models.CharField(max_length=100)
    band_gap = models.CharField(max_length=100)
    has_bandstructure = models.CharField(max_length=100)
    volume = models.CharField(max_length=100)
    nsites = models.CharField(max_length=100)
    theoretical = models.CharField(max_length=100)
    density = models.CharField(max_length=100)
    crystal_system = models.CharField(max_length=100)

    def __str__(self):
        return self.formula
