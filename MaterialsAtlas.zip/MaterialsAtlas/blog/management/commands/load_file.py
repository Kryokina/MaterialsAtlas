from django.core.management.base import BaseCommand
from blog.models import Material
import csv

class Command(BaseCommand):
    help = 'Loads a csv file into Django database'

    def add_arguments(self, parser):
        parser.add_argument('file_location', type=str, help='CSV file path')

    def handle(self, *args, **kwargs):
        file_location = kwargs['file_location']
    
        with open(file_location, 'r') as csv_file:
            csv_reader = csv.reader(csv_file)
        
            next(csv_reader)
        
            for line in csv_reader:
                temp_mat = Material(
                                    mat_id=line[0], formula=line[1],
                                    spacegroup=line[2], formation_energy=line[3],
                                    e_above_hull=line[4], band_gap=line[5],
                                    has_bandstructure=line[6],
                                    volume=line[7],
                                    nsites=line[8], theoretical=line[9],
                                    density=line[11], crystal_system=line[12]
                                )
                if Material.objects.filter(mat_id=temp_mat.mat_id).exists():
                    continue;
                else:
                    temp_mat.save()

        self.stdout.write(self.style.SUCCESS('CSV File has been uploaded.'))

